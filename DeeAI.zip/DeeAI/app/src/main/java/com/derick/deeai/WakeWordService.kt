package com.derick.deeai

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Foreground microphone service. Wake detection = continuous SpeechRecognizer loop matching "Hey DEE".
 * No third-party wake-word keys are used. Trade-offs (battery, beeps, accuracy) are in the README.
 */
class WakeWordService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var engine: DeeEngine
    private var wake: Listener? = null
    private var running = false
    private val wakeRegex = Regex("\\b(hey|hay|hi|a)[ ,]+(dee|d|di|de|dea|deedee)\\b[\\s,.!]*(.*)", RegexOption.IGNORE_CASE)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() { super.onCreate(); engine = DeeEngine(this, allowLaunch = false) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_LISTEN -> if (running) { wake?.stop(); engine.converse { listenForWake() } }
            else -> if (!running) begin()
        }
        return START_STICKY
    }

    private fun begin() {
        Notifier.channels(this)
        try {
            ServiceCompat.startForeground(this, 1001, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) { // permission missing or Android refused a background start
            DeeState.reply.value = "Android refused to start background listening: ${e.javaClass.simpleName}"
            stopSelf(); return
        }
        running = true; DeeState.serviceRunning.value = true
        listenForWake()
    }

    private fun listenForWake() {
        if (!running) return
        wake = Listener(this, object : Listener.Callback {
            override fun onFinal(text: String) {
                val m = wakeRegex.find(text)
                when {
                    m == null -> restart(300)
                    m.groupValues[3].isNotBlank() -> engine.process(m.groupValues[3]) { listenForWake() } // "Hey DEE what time is it"
                    else -> engine.converse { listenForWake() }
                }
            }
            override fun onError(code: Int) {
                if (code == 9) { stopSelf(); return } // permission revoked
                restart(if (code == 8) 1500 else 400) // 8 = recognizer busy
            }
        }).also { it.start() }
    }

    private fun restart(delay: Long) { wake?.stop(); main.postDelayed({ listenForWake() }, delay) }

    private fun notification() = NotificationCompat.Builder(this, Notifier.CH_SERVICE)
        .setSmallIcon(R.drawable.ic_stat_dee).setContentTitle("DEE is listening for \"Hey DEE\"")
        .setOngoing(true).setSilent(true)
        .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
        .addAction(0, "Listen now", PendingIntent.getService(this, 1, Intent(this, WakeWordService::class.java).setAction(ACTION_LISTEN), PendingIntent.FLAG_IMMUTABLE))
        .addAction(0, "Stop", PendingIntent.getService(this, 2, Intent(this, WakeWordService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE))
        .build()

    override fun onDestroy() {
        running = false; main.removeCallbacksAndMessages(null); wake?.stop(); engine.shutdown()
        DeeState.serviceRunning.value = false; super.onDestroy()
    }

    companion object {
        const val ACTION_LISTEN = "com.derick.deeai.LISTEN"
        const val ACTION_STOP = "com.derick.deeai.STOP"
        fun start(c: Context) = ContextCompat.startForegroundService(c, Intent(c, WakeWordService::class.java))
        fun stop(c: Context) { c.stopService(Intent(c, WakeWordService::class.java)) }
    }
}
