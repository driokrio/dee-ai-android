package com.derick.deeai

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class Speaker(ctx: Context) {
    private var ready = false
    private val main = Handler(Looper.getMainLooper())
    private val tts: TextToSpeech = TextToSpeech(ctx.applicationContext) { s ->
        ready = s == TextToSpeech.SUCCESS
        if (ready) tts.language = Locale.getDefault()
    }

    fun speak(text: String, onDone: () -> Unit) {
        if (!ready) { onDone(); return }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post(onDone) }
            @Deprecated("deprecated") override fun onError(id: String?) { main.post(onDone) }
        })
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dee")
    }

    fun stop() { tts.stop() }
    fun shutdown() { tts.stop(); tts.shutdown() }
}
