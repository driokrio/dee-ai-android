package com.derick.deeai

import kotlinx.coroutines.flow.MutableStateFlow

enum class Status { Idle, Listening, Thinking, Speaking }

/** Shared UI state, written by DeeEngine (activity or service), read by Compose. */
object DeeState {
    val status = MutableStateFlow(Status.Idle)
    val heard = MutableStateFlow("")
    val reply = MutableStateFlow("")
    val serviceRunning = MutableStateFlow(false)
}
