package com.derick.deeai

import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService

/** Registers DEE in Settings > Default digital assistant app. */
class DeeVoiceInteractionService : VoiceInteractionService()

class DeeSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = DeeSession(this)
}

class DeeSession(private val svc: DeeSessionService) : VoiceInteractionSession(svc) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        startAssistantActivity(Intent(svc, MainActivity::class.java).putExtra("from_assist", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}

/** Required by the assistant metadata. Deliberately inert: DEE uses the system recognizer. Do not select it as your speech engine. */
class DeeRecognitionService : RecognitionService() {
    override fun onStartListening(i: Intent?, cb: Callback?) { cb?.error(android.speech.SpeechRecognizer.ERROR_CLIENT) }
    override fun onCancel(cb: Callback?) {}
    override fun onStopListening(cb: Callback?) {}
}
