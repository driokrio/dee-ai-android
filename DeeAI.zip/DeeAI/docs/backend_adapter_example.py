"""
OPTIONAL example. Add this route to your EXISTING FastAPI backend; do not replace your backend or SQLite memory.
Replace `your_existing_chat_function` with whatever your backend already uses to answer (and remember) messages.
"""
import os
from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

router = APIRouter()
DEE_TOKEN = os.environ.get("DEE_APP_TOKEN", "")  # same value you type into the app's Settings

class DeeRequest(BaseModel):
    message: str
    session_id: str
    client: str = ""

@router.post("/chat")
def dee_chat(req: DeeRequest, authorization: str = Header(default="")):
    if DEE_TOKEN and authorization != f"Bearer {DEE_TOKEN}":
        raise HTTPException(status_code=401, detail="bad token")
    reply = your_existing_chat_function(req.message, session=req.session_id)  # noqa: F821
    return {"reply": reply}
