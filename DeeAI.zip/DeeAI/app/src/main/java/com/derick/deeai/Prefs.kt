package com.derick.deeai

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.util.UUID

/** Settings. The optional backend token is the user's own, entered by them, and kept in encrypted storage. No keys ship in the APK. */
object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("dee", Context.MODE_PRIVATE)
    private fun secure(c: Context) = EncryptedSharedPreferences.create(
        c, "dee_secure", MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun endpoint(c: Context) = p(c).getString("endpoint", "") ?: ""
    fun setEndpoint(c: Context, v: String) = p(c).edit().putString("endpoint", v.trim()).apply()
    fun onboarded(c: Context) = p(c).getBoolean("onboarded", false)
    fun setOnboarded(c: Context) = p(c).edit().putBoolean("onboarded", true).apply()
    fun token(c: Context): String = runCatching { secure(c).getString("token", "") }.getOrNull() ?: ""
    fun setToken(c: Context, v: String) { runCatching { secure(c).edit().putString("token", v.trim()).apply() } }
    fun sessionId(c: Context): String = p(c).getString("sid", null) ?: UUID.randomUUID().toString().also { p(c).edit().putString("sid", it).apply() }
}
