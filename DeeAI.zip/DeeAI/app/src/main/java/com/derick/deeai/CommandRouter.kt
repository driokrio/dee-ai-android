package com.derick.deeai

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.text.DateFormat
import java.util.Date

/** Local commands first (offline, instant); everything else goes to the Python backend. */
class CommandRouter(private val ctx: Context) {

    suspend fun handle(raw: String, allowLaunch: Boolean): String {
        val t = raw.lowercase().replace(Regex("^\\W*(hey|hay|hi|a)\\W+(dee|d|di|de|dea|deedee)\\b[\\s,.!]*"), "").trim()
        if (t.isEmpty()) return "I'm listening."
        return when {
            Regex("\\bwhat('s| is)? the time\\b|\\bwhat time is it\\b|^time$").containsMatchIn(t) ->
                "It's " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date()) + "."
            Regex("\\bwhat('s| is)? (the )?(date|day)\\b|\\bwhat day is it\\b|\\btoday's date\\b").containsMatchIn(t) ->
                "Today is " + DateFormat.getDateInstance(DateFormat.FULL).format(Date()) + "."
            t.startsWith("open ") || t.startsWith("launch ") || t.startsWith("start ") -> openApp(t.substringAfter(' ').trim(), allowLaunch)
            t.startsWith("search for ") || t.startsWith("google ") || t.startsWith("search the web for ") ->
                webSearch(t.substringAfter(if (t.startsWith("google ")) "google " else if (t.startsWith("search the web for ")) "for " else "for ").trim(), allowLaunch)
            else -> BackendClient.ask(ctx, raw).getOrElse { "I couldn't reach my backend. ${it.message}" }
        }
    }

    private fun launch(intent: Intent, title: String, allow: Boolean) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (allow) ctx.startActivity(intent) else Notifier.offerLaunch(ctx, title, intent)
    }

    private fun openApp(name: String, allow: Boolean): String {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.filter { it.loadLabel(pm).toString().lowercase() == name }.ifEmpty {
            apps.filter { it.loadLabel(pm).toString().lowercase().contains(name) }
        }.firstOrNull() ?: return "I couldn't find an app called $name."
        val intent = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "I can't launch $name."
        launch(intent, "Open ${hit.loadLabel(pm)}", allow)
        return if (allow) "Opening ${hit.loadLabel(pm)}." else "Tap the notification to open ${hit.loadLabel(pm)}."
    }

    private fun webSearch(q: String, allow: Boolean): String {
        if (q.isBlank()) return "What should I search for?"
        launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))), "Search: $q", allow)
        return if (allow) "Searching for $q." else "Tap the notification to see results for $q."
    }
}
