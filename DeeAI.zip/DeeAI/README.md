# DEE AI 2.0 — Android assistant (created by Derick)

Native Kotlin + Jetpack Compose. Min Android 8.0 (API 26), target/compile API 35.

## STATUS — read this first
This project was **written but NOT compiled or run** by its author tool: the environment had no Android SDK,
no Gradle and no internet. So nothing below is "tested". Expect to fix a small compile error or two on first build.
Everything marked **[device test]** needs a physical phone.

## Build the APK (pick one)

### A. Android Studio (easiest)
1. Install Android Studio (current stable). Open this folder (`DeeAI`). Let it sync (it downloads Gradle 8.9 + SDK 35 when asked).
2. Menu: Build > Build Bundle(s)/APK(s) > Build APK(s).
3. APK: `app/build/outputs/apk/debug/app-debug.apk`

### B. Command line
Needs JDK 17, Android SDK (platform 35, build-tools), Gradle 8.9:
```
export ANDROID_HOME=/path/to/android-sdk
gradle assembleDebug
```
(`gradlew` is not included because it can't be generated offline. Android Studio creates it, or run `gradle wrapper --gradle-version 8.9` once.)

### C. No install at all: GitHub Actions
Push this folder to a GitHub repo. `.github/workflows/build-apk.yml` builds the APK; download it from the run's Artifacts.

## Install on your phone
1. Copy `app-debug.apk` to the phone, open it, allow "install unknown apps" for your file manager. Or: `adb install app-debug.apk` with USB debugging on.

## Connect your backend (existing Python + SQLite untouched)
In the app: Settings > endpoint (must be `https://`) and optional token. Contract:
```
POST <endpoint>  {"message","session_id","client"}  ->  {"reply": "..."}
```
If your backend's route differs, add the route in `docs/backend_adapter_example.py` beside it. The app contains no API keys.

## What is implemented
- Glowing animated orb UI (Compose canvas), onboarding, settings
- Speech recognition (Android SpeechRecognizer) + spoken replies (TextToSpeech)
- Commands: time, date, open app, web search (local); everything else -> your backend
- Foreground microphone service with notification buttons "Listen now" / "Stop"
- "Hey DEE" detection, default-assistant registration (VoiceInteractionService), assist intent, show-when-locked activity

## Restrictions and honest caveats
- **Wake word is approximate.** It loops the system SpeechRecognizer and regex-matches "hey dee". It can miss it, mishear it (false triggers), use noticeable battery, and some devices play a beep on each restart. [device test] A dedicated engine (e.g. Picovoice Porcupine, needs your own access key and a trained "Hey DEE" model) is the proper upgrade.
- **Android 14/15:** a microphone foreground service must be started while the app is visible. Starting it from boot or background is blocked, so after a reboot open DEE and flip the switch again. No boot receiver is included on purpose.
- **Background launches blocked:** when "Hey DEE" is heard in the background, "open X" / web search show a tap-to-open notification instead of launching directly.
- **Lock screen:** the activity can show over the lock screen and the assistant declares keyguard support, but whether the mic service and recognizer work while locked varies by Android version/OEM. [device test]
- **Default assistant:** Settings > open assistant settings > choose DEE AI 2.0. Gesture/button behavior (and whether Google Assistant must be replaced) differs by manufacturer. [device test]
- **OEM battery managers** (Xiaomi, Oppo, Vivo, Samsung, Huawei...) may kill the service; exempt DEE from battery optimization. [device test]
- Speech recognition may use Google's servers unless an offline language pack is installed.
- `DeeRecognitionService` is an inert stub required by the assistant metadata; do not pick it as your speech engine.

## Test checklist on a real phone
1. Install, finish onboarding, grant mic + notifications. 2. Tap orb, say "what time is it". 3. Say "open Chrome". 4. Settings: set endpoint, "Save and test". 5. Ask a question your backend answers. 6. Switch on "Always listen", lock phone, say "Hey DEE, what time is it". 7. Set as default assistant, trigger via your assistant gesture.
