# default rules are enough; no reflection used
