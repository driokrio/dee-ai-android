package com.derick.deeai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

private val Bg = Color(0xFF050A14)
private val Accent = Color(0xFF38B6FF)

fun hasMic(c: Context) = ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
private fun perms() = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS) else arrayOf(Manifest.permission.RECORD_AUDIO)

class MainActivity : ComponentActivity() {
    private lateinit var engine: DeeEngine
    private var assist by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = DeeEngine(this, allowLaunch = true)
        assist = isAssist(intent)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Bg)) {
                Surface(Modifier.fillMaxSize(), color = Bg) { DeeApp(engine, assist) { assist = false } }
            }
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); assist = isAssist(intent) }
    override fun onDestroy() { engine.shutdown(); super.onDestroy() }
    private fun isAssist(i: Intent?) = i?.getBooleanExtra("from_assist", false) == true || i?.action == Intent.ACTION_ASSIST
}

@Composable
fun DeeApp(engine: DeeEngine, autoListen: Boolean, onConsumed: () -> Unit) {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(if (Prefs.onboarded(ctx)) "main" else "onboarding") }
    when (screen) {
        "onboarding" -> Onboarding { Prefs.setOnboarded(ctx); screen = "main" }
        "settings" -> SettingsScreen { screen = "main" }
        else -> MainScreen(engine, autoListen, onConsumed) { screen = "settings" }
    }
}

@Composable
fun Onboarding(done: () -> Unit) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { done() }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Welcome to DEE AI 2.0", style = MaterialTheme.typography.headlineMedium, color = Accent)
        Text("DEE is a voice assistant made by Derick. Before we start, here is exactly what DEE asks for and why:")
        Text("• Microphone — to hear \"Hey DEE\" and your commands. Audio is processed by your phone's speech recognizer; DEE never records to storage.")
        Text("• Notifications — to show the always-on listening notice (Android requires it) and the Listen / Stop buttons.")
        Text("• Internet — to send your request text to the backend address you configure in Settings. Nothing is sent until you set one.")
        Text("Always-on listening is optional and off until you switch it on. You can stop it anytime from the notification.", color = Color.LightGray)
        Button(onClick = { launcher.launch(perms()) }, Modifier.fillMaxWidth()) { Text("Continue and grant permissions") }
        TextButton(onClick = done, Modifier.fillMaxWidth()) { Text("Skip for now") }
    }
}

@Composable
fun MainScreen(engine: DeeEngine, autoListen: Boolean, onConsumed: () -> Unit, openSettings: () -> Unit) {
    val ctx = LocalContext.current
    val status by DeeState.status.collectAsState()
    val heard by DeeState.heard.collectAsState()
    val reply by DeeState.reply.collectAsState()
    val svc by DeeState.serviceRunning.collectAsState()
    var pendingWake by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasMic(ctx)) { if (pendingWake) WakeWordService.start(ctx) else engine.converse() }
        pendingWake = false
    }
    LaunchedEffect(autoListen) {
        if (autoListen) { onConsumed(); if (hasMic(ctx)) engine.converse() else launcher.launch(perms()) }
    }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("DEE AI 2.0", color = Accent, style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = openSettings) { Text("Settings") }
        }
        Spacer(Modifier.height(12.dp))
        Orb(status, Modifier.size(280.dp).clickable {
            if (hasMic(ctx)) engine.converse() else launcher.launch(perms())
        })
        Text(when (status) { Status.Idle -> "Tap the orb to talk"; Status.Listening -> "Listening…"; Status.Thinking -> "Thinking…"; Status.Speaking -> "Speaking…" }, color = Accent)
        Spacer(Modifier.height(16.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            if (heard.isNotBlank()) Text("\"$heard\"", color = Color.Gray, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            if (reply.isNotBlank()) Text(reply, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyLarge)
        }
        Row(Modifier.fillMaxWidth().background(Color(0xFF0B1424)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Always listen for \"Hey DEE\"")
                Text("Runs a microphone service with a notification", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = svc, onCheckedChange = { on ->
                if (!on) WakeWordService.stop(ctx)
                else if (hasMic(ctx)) WakeWordService.start(ctx) else { pendingWake = true; launcher.launch(perms()) }
            })
        }
    }
}

@Composable
fun SettingsScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var endpoint by remember { mutableStateOf(Prefs.endpoint(ctx)) }
    var token by remember { mutableStateOf(Prefs.token(ctx)) }
    var result by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall, color = Accent)
        OutlinedTextField(endpoint, { endpoint = it }, label = { Text("Backend HTTPS endpoint") }, placeholder = { Text("https://your-server.example/chat") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(token, { token = it }, label = { Text("Backend access token (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Text("The token is stored encrypted on this phone. Your AI provider keys stay on your server, never in this app.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        Button(onClick = {
            Prefs.setEndpoint(ctx, endpoint); Prefs.setToken(ctx, token); result = "Testing…"
            scope.launch { result = BackendClient.ask(ctx, "Hello DEE, connection test.").fold({ "Connected. Reply: $it" }, { "Failed: ${it.message}" }) }
        }, Modifier.fillMaxWidth()) { Text("Save and test connection") }
        if (result.isNotBlank()) Text(result)
        HorizontalDivider()
        Text("Default assistant", style = MaterialTheme.typography.titleMedium)
        Text("Choose DEE AI 2.0 under \"Digital assistant app\". Then your assistant gesture or button opens DEE.", color = Color.Gray)
        OutlinedButton(onClick = {
            val i = Intent(Settings.ACTION_VOICE_INPUT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { ctx.startActivity(i) }.onFailure { ctx.startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }, Modifier.fillMaxWidth()) { Text("Open assistant settings") }
        OutlinedButton(onClick = back, Modifier.fillMaxWidth()) { Text("Back") }
    }
}
