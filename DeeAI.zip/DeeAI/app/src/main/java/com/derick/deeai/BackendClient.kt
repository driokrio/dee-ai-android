package com.derick.deeai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * Talks to YOUR existing Python backend. Contract (adapt the backend route, not the app, if yours differs):
 *   POST <endpoint>   {"message": "...", "session_id": "...", "client": "dee-android-2.0"}
 *   -> 200            {"reply": "..."}
 * The backend keeps its own SQLite memory and holds its own API keys.
 */
object BackendClient {
    suspend fun ask(ctx: Context, text: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = Prefs.endpoint(ctx)
            require(endpoint.isNotBlank()) { "No backend endpoint set. Open Settings." }
            require(endpoint.startsWith("https://")) { "Endpoint must start with https://" }
            val conn = (URL(endpoint).openConnection() as HttpsURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 10_000; readTimeout = 30_000; doOutput = true
                setRequestProperty("Content-Type", "application/json")
                Prefs.token(ctx).takeIf { it.isNotBlank() }?.let { setRequestProperty("Authorization", "Bearer $it") }
            }
            val body = JSONObject().put("message", text).put("session_id", Prefs.sessionId(ctx)).put("client", "dee-android-2.0").toString()
            conn.outputStream.use { it.write(body.toByteArray()) }
            val code = conn.responseCode
            val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            check(code in 200..299) { "Backend returned HTTP $code" }
            JSONObject(raw).optString("reply").ifBlank { error("Backend sent an empty reply") }
        }
    }
}
