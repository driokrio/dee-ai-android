package com.derick.deeai

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** One conversation turn: listen -> route -> speak. Used by the activity, the assistant session and the service. */
class DeeEngine(private val ctx: Context, private val allowLaunch: Boolean) {
    private val speaker = Speaker(ctx)
    private val router = CommandRouter(ctx)
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var listener: Listener? = null

    fun converse(onIdle: () -> Unit = {}) {
        speaker.stop()
        DeeState.status.value = Status.Listening; DeeState.heard.value = ""
        listener = Listener(ctx, object : Listener.Callback {
            override fun onPartial(text: String) { DeeState.heard.value = text }
            override fun onFinal(text: String) { if (text.isBlank()) idle(onIdle) else process(text, onIdle) }
            override fun onError(code: Int) {
                DeeState.reply.value = if (code == 7 || code == 6) "I didn't catch that." else "Speech recognition error ($code)."
                idle(onIdle)
            }
        }).also { it.start() }
    }

    fun process(text: String, onIdle: () -> Unit = {}) {
        DeeState.heard.value = text; DeeState.status.value = Status.Thinking
        scope.launch {
            val reply = runCatching { router.handle(text, allowLaunch) }.getOrElse { "Something went wrong: ${it.message}" }
            DeeState.reply.value = reply; DeeState.status.value = Status.Speaking
            speaker.speak(reply) { idle(onIdle) }
        }
    }

    private fun idle(onIdle: () -> Unit) { DeeState.status.value = Status.Idle; onIdle() }

    fun cancel() { listener?.stop(); speaker.stop(); DeeState.status.value = Status.Idle }
    fun shutdown() { cancel(); speaker.shutdown(); scope.cancel() }
}
