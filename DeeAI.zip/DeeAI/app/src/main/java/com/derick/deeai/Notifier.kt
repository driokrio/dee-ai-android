package com.derick.deeai

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

object Notifier {
    const val CH_SERVICE = "dee_listen"
    const val CH_ACTION = "dee_action"

    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "DEE listening", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ACTION, "DEE actions", NotificationManager.IMPORTANCE_HIGH))
    }

    /** Android blocks activity launches from a background service, so we offer a tap-to-open notification instead. */
    fun offerLaunch(c: Context, title: String, intent: Intent) {
        channels(c)
        val pi = PendingIntent.getActivity(c, intent.hashCode(), intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(c, CH_ACTION).setSmallIcon(R.drawable.ic_stat_dee)
            .setContentTitle(title).setContentText("Tap to continue").setContentIntent(pi).setAutoCancel(true).build()
        runCatching { c.getSystemService(NotificationManager::class.java).notify(2001, n) }
    }
}
