package com.derick.deeai

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate

@Composable
fun Orb(status: Status, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val speed = when (status) { Status.Listening -> 650; Status.Thinking -> 400; Status.Speaking -> 900; Status.Idle -> 2200 }
    val pulse by t.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(speed, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(if (status == Status.Thinking) 1500 else 7000, easing = LinearEasing)), label = "s")
    val glow = if (status == Status.Listening) Color(0xFF38E8FF) else Color(0xFF1E6BFF)
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2 * 0.5f * pulse
        drawCircle(Brush.radialGradient(listOf(glow.copy(0.45f), glow.copy(0.12f), Color.Transparent), c, r * 2.3f), r * 2.3f, c)
        drawCircle(Brush.radialGradient(listOf(Color(0xFFE6FBFF), glow, Color(0xFF0A2A7A)), c, r), r, c)
        rotate(spin, c) {
            val d = r * 1.45f
            val stroke = Stroke(5f, cap = StrokeCap.Round)
            drawArc(glow, 0f, 100f, false, Offset(c.x - d, c.y - d), Size(d * 2, d * 2), style = stroke)
            drawArc(glow.copy(0.6f), 180f, 60f, false, Offset(c.x - d, c.y - d), Size(d * 2, d * 2), style = stroke)
        }
    }
}
